A code and tutorial on how to have the heads-up display display a value of something as a graphical bar for Super Mario World ROM hacking.
